﻿//ISAAC HARO
//Numero mas grande
//Permite ingresar al usuario tres numeros, en el cual se imprima en pantalla el mas grande 
//Version 1.0
//Fecha de creación 04/03/2020
//Ultima fecha de actualizacion 04/03/2020
using System;
//Nombre del Programa
namespace PROGRAMA_N_2_P_2_IEHARO
{
    //Clase
    class Program
    {
        //No retorna ningun valor
        static void Main(string[] args)
        {
            //Ingreso los enteros
            int x1, x2, x3;
            //Escribe la orden "Ingrese el primer valor"
            Console.WriteLine("Ingrese el primer valor");
            //Lee el numero ingresado y lo convierte en entero sin la necesidad de usar un string
            x1 = int.Parse(Console.ReadLine());
            //Escribe la orden "Ingrese el segundo valor"
            Console.WriteLine("Ingrese el segundo valor");
            //Lee el numero ingresado y lo convierte en entero sin la necesidad de usar un string
            x2 = int.Parse(Console.ReadLine());
            //Escribe la orden "Ingrese el tercer valor"
            Console.WriteLine("Ingrese el tercer valor");
            //Lee el numero ingresado y lo convierte en entero sin la necesidad de usar un string
            x3 = int.Parse(Console.ReadLine());
            //Ingreso un if para detectar los numeros iguales 
            if (x1 == x2 || x2 == x3)
            {
                //El programa imprira en pantalla la orden "Todos los números ingresados deben ser distintos" para que reinicie el programa
                Console.WriteLine("Todos los números ingresados deben ser distintos");
            }
            //Ingreso un else if para comprobar si x2 es el numero mayor sino seguira al siguiente else if
            else if  (x2 > x3 && x2 > x1)
            {
                //El programa imprimara "El número mayor es: x2 " si se efectua la orden correctamente
                Console.WriteLine("El número mayor es: " + x2);
            }
            //Ingreso un else if para comprobar si x1 es el numero mayor sino seguira al siguiente else 
            else if (x1 > x3 && x1 > x2)
            {
                //El programa imprimara "El número mayor es: x1 " si se efectua la orden correctamente
                Console.WriteLine("El número mayor es: " + x1);
            }
            //Automaticamente lo que queda sera el numero mayor a x3 
            else
            {
                //El programa imprimara "El número mayor es: x3 " si se efectua la orden correctamente
                Console.WriteLine("El número mayor es: " + x3);
            }
        }
    }
}
