﻿//ISAAC HARO
//Ingreso número entero
// El usuario ingresará un número entero (permitiendo el ingreso de números negativos) y el programa indica si tiene 1, 2, 3 o más de 3 dígitos. 
//Version 1.0
//Fecha de creación 02/03/2020
//Ultima fecha de actualizacion 02/03/2020
//Nos ayuda a tener mas datos
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Nombre del programa
namespace PROGRAMA_N_1_P_2_IEHARO
{
    //Clase
    class Program
    {
        //No devuelve datos
        static void Main(string[] args)
        {
            //Ingreso la variable tipo string
            string ingresonum;
            //Ingreso la variable tipo int
            int ingresonume;
            //El programa pide que ingrese el numero
            Console.WriteLine("Ingrese el número que desee hallar sus dígitos");
            //La variable tipo string lee lo ingresado 
            ingresonum = Console.ReadLine();
            //La variable tipo string se convierte en int 
            ingresonume = int.Parse(ingresonum);
            //Ingreso variables tipo int
            int n = ingresonume, dig=0, x;
            //Uso un condicional if
            if(n<=0)
            {
                //Convierte un numero negativo en un numero positivo
                x = n - (n * 2);
                //Se usa un condicional do-while
                do
                {
                    //Divido la variable para 10 hasta llegar a 0
                    x = x / 10;
                    //Se guarda el nuero de veces que se dividio y se suma 1 por el numero de digitos
                    dig = dig + 1;
                } while (x > 0);
                //La consola imprime en pantalla la respuesta
                Console.WriteLine("Tiene " + dig + " digitos");
                Console.ReadLine();
            }
            //Uso un else para los numeros positivos
            else
            {
                do
                {
                    //Divido la variable para 10 hasta llegar a 0
                    n = n / 10;
                    //Se guarda el nuero de veces que se dividio y se suma 1 por el numero de digitos
                    dig = dig + 1;
                } while (n > 0);
                //La consola imprime en pantalla la respuesta
                Console.WriteLine("Tiene " + dig +" digitos" );
                Console.ReadLine();
            }
        }
    }
}
