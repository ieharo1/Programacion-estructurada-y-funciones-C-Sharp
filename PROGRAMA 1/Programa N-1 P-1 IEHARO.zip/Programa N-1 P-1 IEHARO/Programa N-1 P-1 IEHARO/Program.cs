﻿//ISAAC HARO
//Tablas de multiplicar 
//Crea tablas de multiplicar hasta el 15 por un while
//Version 1.0
//Fecha de creación 02/03/2020
//Ultima fecha de actualizacion 02/03/2020

//Nos ayuda a tener mas datos
using System;
//Nombre del programa
namespace Programa_N_1_P_1_IEHARO
{
   //clase
    class Program
    {
       //no retorna datos
        static void Main(string[] args)
        {
            //Ingreso de enteros
            int y, n, i=1;
            //Ingresa un numero por consola
            Console.WriteLine("Ingrese un número");
            //Lee el numero como una variable tipo int
            n = int.Parse(Console.ReadLine());
            //Usa un while para hacer las tablas
            while (i<=15)
            {
                //multiplica desde 1 hasta 15
                y = n * i;
                //Imprime los resultados
                Console.WriteLine(n+ "x" +i +"=" +y);
                //pasos de 1 en 1
                i++;
            }
        }
    }
}
