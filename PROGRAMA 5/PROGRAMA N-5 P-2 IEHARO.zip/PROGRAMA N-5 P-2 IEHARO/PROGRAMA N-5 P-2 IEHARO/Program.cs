﻿//ISAAC HARO
//Identificardor de provincias
//Al ingresar el número de la provicia, se le imprimira en pantalla la provicia a la que pertnece el dígito
//Version 1.0
//Fecha de creación 02/03/2020
//Ultima fecha de actualizacion 02/03/2020

//Nos ayuda a tener mas datos
using System;
//Nombre del programa
namespace PROGRAMAN_5P_2IEHARO
{
   //Clase
    class Program
    {
       //No retorna los valores
        static void Main(string[] args)
        {
            //Ingreso de mis números enteros
            int ecuador = 4;
            //La consola pide al usuario que ingrese el número de la provincia
            Console.WriteLine("Ingrese el número de la provincia que desea imprimir en pantalla");
            //El entero lee el dígito ingresado
            ecuador = int.Parse(Console.ReadLine());
            //Uso del switch
            switch (ecuador)
            {
                // Ingreso del caso 
                case 01:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Azuay");
                    //Termina aquí el programa
                    break;
                // Ingreso del caso 
                case 02:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Bolivar");
                    //Termina aquí el programa
                    break;
                // Ingreso del caso 
                case 03:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Cañar");
                    //Termina aquí el programa
                    break;
                // Ingreso del caso 
                case 04:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Carhi");
                    //Termina aquí el programa
                    break;
                // Ingreso del caso 
                case 05:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Cotopaxi");
                    //Termina aquí el programa
                    break;
                // Ingreso del caso 
                case 06:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Chimborazo");
                    //Termina aquí el programa
                    break;
                // Ingreso del caso 
                case 07:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("El Oro");
                    //Termina aquí el programa
                    break;
                // Ingreso del caso 
                case 08:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Esmeraldas");
                    //Termina aquí el programa
                    break;
                // Ingreso del caso 
                case 09:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Guayas");
                    //Termina aquí el programa
                    break;
                // Ingreso del caso 
                case 10:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Imbabura");
                    //Termina aquí el programa
                    break;
                // Ingreso del caso 
                case 11:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Loja");
                    //Termina aquí el programa
                    break;
                // Ingreso del caso
                case 12:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Los rios");
                    //Termina aquí el programa
                    break;
                //Ingreso del caso
                case 13:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Manabí");
                    //Termina el programa
                    break;
                //Ingreso del caso
                case 14:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Morona Santiago");
                    //Termina el programa
                    break;
                //Ingreso del caso
                case 15:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Napo");
                    //Termina el programa
                    break;
                //Ingreso del caso
                case 16:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Pastaza");
                    //Termina el programa
                    break;
                //Ingreso del caso
                case 17:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Pichincha");
                    //Termina el programa
                    break;
                //Ingreso del caso
                case 18:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Tungurahua");
                    //Termina el programa
                    break;
                //Ingreso del caso
                case 19:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Zamora Chinchipe");
                    //Termina el programa
                    break;
                //Ingreso del caso
                case 20:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Galápagos");
                    //Termina el programa
                    break;
                //Ingreso del caso
                case 21:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Sucumbios");
                    //Termina el programa
                    break;
                //Ingreso del caso
                case 22:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Orellana");
                    //Termina el programa
                    break;
                //Ingreso del caso
                case 23:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Santo Domingo de los Tsáchilas");
                    //Termina el programa
                    break;
                //Ingreso del caso
                case 24:
                    //La consola escribe la provincia a la que pertenece el número ingresado
                    Console.WriteLine("Santa Elena");
                    //Termina el programa
                    break;
            }
        }
    }
}