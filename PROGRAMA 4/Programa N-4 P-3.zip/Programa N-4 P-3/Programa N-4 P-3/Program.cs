﻿//ISAAC HARO
//Creador de contraseñas
//Crea un contrasela de 4 digitos en el programa y verifica si es la misma contraseña o no
//Version 1.0
//Fecha de creación 13/03/2020
using System;
//Nombre del programa
namespace Programa_N_4_P_3
{
    //Clase
    class Program
    {
        //No retorna datos
        static void Main(string[] args)
        {
            //Ingreso de varibles tipo int
            int contra, comprobar, nile;
            //El programa pide crear una contraseña
            Console.WriteLine("Cree su contraseña de 4 dígitos númericos");
            //Guarda la contraseña creada
            contra = int.Parse(Console.ReadLine());
            //Valida si la contraseña esta o no dentro del rango de los 4 dígitos
            if (contra < 1000 || contra > 9999)
            {
                //En caso de que no este dentro del rengo escribira Contraseña no valida ingrese una nueva contraseña
                Console.WriteLine("Contraseña no valida ingrese una nueva contraseña");
                //Lee la nueva contraseña ingresada
                contra = int.Parse(Console.ReadLine());
                //Si otra vez esta mal la contraseña se generara un bucle hasta que ingrese una contraseña valida
                while(contra< 1000|| contra > 9999)
                {
                    //En caso de que no este dentro del rango escribira contraseña no valida ingrese nueva cotraseña
                    Console.WriteLine("Contraseña no valida ingrese una nueva contraseña");
                    //Lee la nueva contrase;a para validar
                    contra = int.Parse(Console.ReadLine());
                }
            }
            //Si la creacion de la contraseña esta dentro del rango la Contraseña se valida y guarda correctamente
            else
            {
                //El programa verifica que la contraseña es valida
                Console.WriteLine("Contraseña valida y guardada correctamente");
            }
            //El programa pide ingresar la contraseña guardada anteriormente para comparar y que pueda ingresar el usuario
            Console.WriteLine("Ingrese su contraseña de 4 digitos numericos");
            //La contraseña se guarda en una variable
            nile = int.Parse(Console.ReadLine());
            //Se comparan las contraseñas
            if(nile!= contra)
            {
                //El progreme escribe contraseña incorrecta
                Console.WriteLine("Contrasea incorrecta");
                //El programa pide nuevamente que ingrese la contraseña
                Console.WriteLine("Ingrese su contraseña de 4 digitos numericos nuevamente");
                //El programa lee la contraseña
                comprobar = int.Parse(Console.ReadLine());
                //Si las contraseñas coinciden
                if (comprobar == contra)
                {
                    //El programa pondra contraseña correcta
                    Console.WriteLine("Contraseña correcta");
                }
                //Y si no coinciden
                else if (comprobar != contra)
                {
                    //El programa imprimira contrseña incorrecta
                    Console.WriteLine("Contraseña incorrecta");
                    //Ingresa otra vez la contraseña
                    Console.WriteLine("Ingrese su contraseña de 4 digitos numericos nuevamente");
                    //Y compara para ver si es correcta o incorrecta
                    comprobar = int.Parse(Console.ReadLine());
                    while (comprobar != contra)
                    {
                        //El programa imprimira contrseña incorrecta
                        Console.WriteLine("Contraseña incorrecta");
                        //Ingresa otra vez la contraseña
                        Console.WriteLine("Ingrese su contraseña de 4 digitos numericos nuevamente");
                        //Y compara para ver si es correcta o incorrecta
                        comprobar = int.Parse(Console.ReadLine());
                    }
                    Console.WriteLine("Contraseña correcta");
                }
                //Si cumple directamente el parametro se escribira contraseña correcta
                else
                {
                    Console.WriteLine("Contraseña correcta");
                }
            }
        }
    }
}
