﻿//ISAAC HARO
//Calificaión estilo americano
//El programa imprimira en pantalla las calificaciones de los alumnos al estilo amiricano ingresando las notas normales 
//Version 1.0
//Fecha de creación 05/03/2020
//Ultima fecha de actualizacion 05/03/2020
using System;
//Nombre del programa
namespace PROGRAMA_N_4_P_2_IEHARO
{
    //Clase
    class Program
    {
        //No retorna datos
        static void Main(string[] args)
        {
            //Ingreso mi variable tipo int
            int calif;
            //El programa pide al usuario que ingrese los valores
            Console.WriteLine("Ingrese la calificación dentro del rango(0-100)");
            //Los valores seran leídos como calif que es tipo int
            calif = int.Parse(Console.ReadLine());
            //Ingreso un condicional if
            if (calif < 69)
            {
                //Si cumple la orden imprimira en pantalla la nota F
                Console.WriteLine("Su calificación es F ");
            }
            else if (calif >= 69 && calif < 70) //Ingreso un else if para que cumpla otra condicion si la primera no se efectua
            {
                //Si cumple la orden imprimira en pantalla la nota D
                Console.WriteLine("Su calificación es D ");
            }
            else if (calif >= 70 && calif < 80)//Ingreso un else if para que cumpla otra condicion si la primera y segunda no se efectua
            {
                //Si cumple la orden imprimira en pantalla la nota C
                Console.WriteLine("Su calificación es C ");
            }
            else if (calif >= 80 && calif < 90)//Ingreso un else if para que cumpla otra condicion si la primera, segunda y tercera no se efectua
            {
                //Si cumple la orden imprimira en pantalla la nota B
                Console.WriteLine("Su calificación es B ");
            }
            else// Si no cumple ninguna el programa tomara automaticamente la desicion
            {
                //Si cumple la orden imprimira en pantalla la nota A
                Console.WriteLine("Su calificación es A ");
            }
        }
    }
}