﻿//ISAAC HARO
//PAGOS
//Se calcularan los pagos diarios segun el horario nocturno o diurno y que dias a trabajado
//Version 1.0
//Fecha de creación 02/03/2020
//Ultima fecha de actualizacion 02/03/2020
using System;
//Nombre del programa
namespace PROGRAMA_N_3_P_2_IEHARO
{
    //Clase
    class Program
    {
        //No retorna los datos
        static void Main(string[] args)
        {
            //Ingreso la variable int
            int hora, pagdia;
            //Ingreso la variable string
            string entsema, dia;
            //El programa pide el numero de horas trabajadas
            Console.WriteLine("Cuantas horas trabajo");
            //El programa lo lee automaticamente como int
            hora = int.Parse(Console.ReadLine());
            //El programa pide si trabajo entresemana o no
            Console.WriteLine("Trabajo entresemana si ó no");
            //El programa lee como string la respuesta y la convierte en minusculas
            entsema = Console.ReadLine().ToLower();
            //El programa pide si trabajo de dia o de noche
            Console.WriteLine("Trabajo en el día si ó no");
            //El programa lee como string la respuesta y la convierte en minusculas
            dia = Console.ReadLine().ToLower();
            //Ingresamos varios if con el fin de que solo recepten ordenes correctamente
            if (entsema == "si" || entsema == "Si" || entsema == "SI")
            {
                if (dia == "si" || dia == "Si" || dia == "SI")
                {
                    //Multiplica por 15 el numero de horas
                    pagdia = hora * 15;
                    //Imprime en pantalla la respuesta
                    Console.WriteLine("Usted a trabajado entresemana por lo que su pago del dia es: " + pagdia + " por sus horas trabajadas");
                }
                if (dia == "no" || dia == "No" || dia == "NO")
                {
                    //Multiplica por 18 el numero de horas
                    pagdia = hora * 18;
                    //Imprime en pantalla la respuesta
                    Console.WriteLine("Usted a trabajado entresemana por lo que su pago de la noche es: " + pagdia + " por sus horas trabajadas");
                }

            }
            if (entsema == "no" || entsema == "NO" || entsema == "")
            {
                if (dia == "si" || dia == "Si" || dia == "SI")
                {
                    //Multiplica por 15 el numero de horas y le suma 2 extra
                    pagdia = hora * 15 + 2;
                    //Imprime en pantalla la respuesta
                    Console.WriteLine("Usted a trabajado el dia domingo por lo que su pago del dia es: " + pagdia + " por sus horas trabajadas");
                }
                if (dia == "no" || dia == "No" || dia == "NO")
                {
                    //Multiplica por 18 el numero de horas y le suma 3 extra
                    pagdia = hora * 18 + 3;
                    //Imprime en pantalla la respuesta
                    Console.WriteLine("Usted a trabajado el día domingo por lo que su pago de la noche es: " + pagdia + " por sus horas trabajadas");
                }
            }
        }
    }
}

   
                
                
